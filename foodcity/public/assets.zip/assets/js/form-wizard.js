/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!********************************************!*\
  !*** ./resources/assets/js/form-wizard.js ***!
  \********************************************/
(function ($) {
  "use strict";

  //accordion-wizard
  var options = {
    mode: 'wizard',
    autoButtonsNextClass: 'btn btn-primary float-end',
    autoButtonsPrevClass: 'btn btn-light',
    stepNumberClass: 'badge rounded-pill bg-primary me-2',
    onSubmit: function onSubmit() {
      alert('Form submitted!');
      return true;
    }
  };
  $("#form").accWizard(options);
})(jQuery);
/******/ })()
;