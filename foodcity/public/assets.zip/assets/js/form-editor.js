/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!********************************************!*\
  !*** ./resources/assets/js/form-editor.js ***!
  \********************************************/
$(function (e) {
  $('.content').richText();
  $('.content2').richText();
});
/******/ })()
;