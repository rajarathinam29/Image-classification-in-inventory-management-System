/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*******************************************!*\
  !*** ./resources/assets/js/newsticker.js ***!
  \*******************************************/
$(function (e) {
  'use strict';

  $('.js-conveyor-example').jConveyorTicker({
    reverse_elm: true
  });
});
/******/ })()
;