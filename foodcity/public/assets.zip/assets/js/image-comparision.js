/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************************!*\
  !*** ./resources/assets/js/image-comparision.js ***!
  \**************************************************/
$(function () {
  $(".twentytwenty-container[data-orientation!='vertical']").twentytwenty({
    default_offset_pct: 0.7
  });
  $(".twentytwenty-container[data-orientation='vertical']").twentytwenty({
    default_offset_pct: 0.3,
    orientation: 'vertical'
  });
});
/******/ })()
;