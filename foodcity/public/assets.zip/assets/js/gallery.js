/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./resources/assets/js/gallery.js ***!
  \****************************************/
(function ($) {
  "use strict";

  lightGallery(document.getElementById('lightgallery'));
})(jQuery);
/******/ })()
;