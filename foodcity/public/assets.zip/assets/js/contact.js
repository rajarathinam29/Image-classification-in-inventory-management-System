/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./resources/assets/js/contact.js ***!
  \****************************************/
$(function () {
  var ps = new PerfectScrollbar('#mainContactList', {
    useBothWheelAxes: false,
    suppressScrollX: false
  });
});
/******/ })()
;