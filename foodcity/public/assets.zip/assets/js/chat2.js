/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./resources/assets/js/chat2.js ***!
  \**************************************/
$(function () {
  'use strict';

  $('#chatActiveContacts').lightSlider({
    autoWidth: true,
    controls: false,
    pager: false,
    slideMargin: 12
  });
  var ps = new PerfectScrollbar('#ChatList', {
    useBothWheelAxes: false,
    suppressScrollX: false
  });
  var ps1 = new PerfectScrollbar('#ChatBody', {
    useBothWheelAxes: false,
    suppressScrollX: false
  });
  $('[data-bs-toggle="tooltip"]').tooltip();
});
/******/ })()
;