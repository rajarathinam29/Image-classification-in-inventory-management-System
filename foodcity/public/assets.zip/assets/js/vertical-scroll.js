/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************************************!*\
  !*** ./resources/assets/js/vertical-scroll.js ***!
  \************************************************/
$(function () {
  $(".vertical-scroll").bootstrapNews({
    newsPerPage: 6,
    autoplay: true,
    pauseOnHover: true,
    navigation: false,
    direction: 'down',
    newsTickerInterval: 2500,
    onToDo: function onToDo() {
      //console.log(this);
    }
  });
  $(".vertical-scroll1").bootstrapNews({
    newsPerPage: 2,
    autoplay: true,
    pauseOnHover: true,
    navigation: false,
    direction: 'down',
    newsTickerInterval: 2500,
    onToDo: function onToDo() {
      //console.log(this);
    }
  });
});
/******/ })()
;